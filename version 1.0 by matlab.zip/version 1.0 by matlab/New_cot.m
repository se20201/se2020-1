function newcot = New_cot(x)

newcot = 1/New_tan(x);
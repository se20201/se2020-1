function newtan = New_tan(x)

newtan = New_sin(x)/New_cos(x);